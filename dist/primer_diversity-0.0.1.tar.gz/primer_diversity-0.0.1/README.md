Primer Diversity is a package used to check the nucleotide diversity of primer hitting results of the given sequence 
